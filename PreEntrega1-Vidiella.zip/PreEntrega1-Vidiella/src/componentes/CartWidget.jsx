function CartWidget() {
    return (
        <div>
            <button id="boton-carrito"><i class="fas fa-shopping-cart"></i><span id="contadorCarrito">0</span></button>   
        </div>
    );
}

export default CartWidget;